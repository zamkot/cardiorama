#ifndef PLOT_H
#define PLOT_H

#include <QtWidgets/QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QHorizontalBarSeries>
#include <QtCharts/QLineSeries>
#include <QtCharts/QCategoryAxis>
#include <QtCharts/QHorizontalStackedBarSeries>
#include <QtCharts>
#include <QString>
#include <cmath>
#include <algorithm>
#include <chart.h>

QT_CHARTS_USE_NAMESPACE

Chart *setChart_ECG_Baseline();
Chart *setChart_R_peaks(std::vector<int> r_peaks);
Chart *setChart_QRS();
Chart *setChart_T_Waves_ALT();
Chart *setChart_HRV_1();
Chart *setChart_HRV_2();
Chart *setChart_HVR_DFA();


#endif // PLOT_H
