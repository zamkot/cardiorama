#ifndef MYANALYSIS_H
#define MYANALYSIS_H


class MyAnalysis
{
public:
    MyAnalysis();
};

#endif // MYANALYSIS_H