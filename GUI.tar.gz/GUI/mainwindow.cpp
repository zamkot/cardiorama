#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QString>
#include <QDebug>
#include "chart.h"
#include "plot.h"
#include "chartview.h"
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtCharts/QValueAxis>


MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("ECG ANALYSIS");
    ui->Tab->setCurrentIndex(0);

    // AUTO configuraton
    ui->Hilbert->setChecked(true);
    short choice = 0;
    RPeaksConfig rPeaksConfig{choice};
    analysis.sendRPeaksConfig(rPeaksConfig);

    ui->Buttherworth->setChecked(true);


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_OpenFile_clicked()
{
    QString filename=QFileDialog::getOpenFileName(
                this,
                tr("Open File"),
                QDir::currentPath(),
                tr("DAT files(*.dat)"));

    ui->textBrowser->setText(QString("File path: %1").arg(filename));
    loadFile(filename);

}

void MainWindow::loadFile(QString path)
{
    analysis.loadFile(path.toUtf8().constData());
}


void MainWindow::on_Hilbert_clicked()
{
    short choice = 0;
    RPeaksConfig rPeaksConfig{choice};
    analysis.sendRPeaksConfig(rPeaksConfig);

}

void MainWindow::on_PanTompkins_clicked()
{
    short choice = 1;
    RPeaksConfig rPeaksConfig{choice};
    analysis.sendRPeaksConfig(rPeaksConfig);

}

void MainWindow::on_RunECG_BASELINE_clicked()
{
    ui->Tab->setCurrentIndex(0);

    QWidget *ECG_BASELINE= QApplication::activeWindow();
    ChartView *plot = ECG_BASELINE->findChild<ChartView*>("BASELINE");
    Chart *baseline =  setChart_ECG_Baseline();
    plot->setChart(baseline);
    plot->setRenderHints(QPainter::Antialiasing);

}

void MainWindow::on_RunR_PEAKS_clicked()
{

     ui->Tab->setCurrentIndex(1);

     auto result = analysis.runRPeaks();
     for (size_t i =0;i<result.rpeaks.size();i++)
     {
         qDebug()<<result.rpeaks[i];

     }

     Chart *chart = setChart_R_peaks(result.rpeaks);
     QWidget *R_PEAKS= QApplication::activeWindow();
     QScrollArea *scroll = R_PEAKS->findChild< QScrollArea*>("scrollArea");
     ChartView *plot = new ChartView(chart, R_PEAKS);
     chart->axisX()->setRange(0,50);
     scroll->setWidget(plot);

     //ChartView *plot = R_PEAKS->findChild<ChartView*>("RPEAKSCHART");
     //plot->setChart(chart);
     //rectangular zooming sucks
     //plot->setRubberBand( QChartView::RectangleRubberBand);
     plot->setRenderHints(QPainter::Antialiasing);
     plot->grabGesture(Qt::PanGesture);
     plot->grabGesture(Qt::PinchGesture);

}


void MainWindow::on_RunWAVES_clicked()
{
    ui->Tab->setCurrentIndex(2);

    auto result = analysis.runWaves();
    for (size_t i =0;i<result.qrsOnset.size();i++)
    {
        qDebug()<<result.qrsOnset[i];
    }

    for (size_t i =0;i<result.qrsEnd.size();i++)
    {
        qDebug()<<result.qrsEnd[i];
    }

    for (size_t i =0;i<result.tEnd.size();i++)
    {
       qDebug()<<result.tEnd[i];
    }

    for (size_t i =0;i<result.pOnset.size();i++)
    {
        qDebug()<<result.pOnset[i];
    }

    for (size_t i =0;i<result.pEnd.size();i++)
    {
       qDebug()<<result.pEnd[i];
    }

}


void MainWindow::on_RunT_WAVES_ALT_clicked()
{

    ui->Tab->setCurrentIndex(3);

}

void MainWindow::on_RunHRV1_clicked()
{

    ui->Tab->setCurrentIndex(4);

}

void MainWindow::on_RunHRV2_clicked()
{
    ui->Tab->setCurrentIndex(5);

    QWidget *HRV2= QApplication::activeWindow();
    ChartView *bar_chart = HRV2->findChild<ChartView*>("HRV2CHART");
    Chart *histogram = setChart_HRV_2();
    bar_chart->setChart(histogram);
    bar_chart->setRenderHints(QPainter::Antialiasing);
}

void MainWindow::on_RunHRV_DFA_clicked()
{
    ui->Tab->setCurrentIndex(6);

}

void MainWindow::on_RunHEART_CLASS_clicked()
{

    ui->Tab->setCurrentIndex(7);

}



