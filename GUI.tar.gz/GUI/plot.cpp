#include <plot.h>
#include <chart.h>
#include <chartview.h>


QT_CHARTS_USE_NAMESPACE

Chart *setChart_R_peaks(std::vector<int> r_peaks)
{
   //Question: Czy os x ma być w próbkach, czy w czasie?

   //  QValueAxis *x_axis = new QValueAxis();

   //    x_axis->setTickCount(10);

    unsigned int i = 0;
    // tu będzie wektor danymi x - sygnał EKG
    //std::vector<int> dane_x= {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,
    //                         51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100};
    std::vector<int> dane_x(300);
    std::iota(dane_x.begin(), dane_x.end(), 1);
    //a tu bedzie wektor z wartościami na ygrekach - sygnał EKG
    std::vector<int> dane_y = {2,45,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7
                              ,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7
                              ,2,45,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7,2,15,1,4,22,6,8,30,29,7};

    //tu będzie wektor z r pikami
    //std::vector<int> r_peaks = {2,3,5};

    //seria danych bazowych - sygnał EKG
    QLineSeries *series_line = new QLineSeries();

    //seria danych - wektor r pików
    QScatterSeries *series_scatter2 = new QScatterSeries();


    for(i = 0; i < r_peaks.size(); i++)
    {
        series_scatter2->append(r_peaks[i], dane_y[r_peaks[i] - 1]);
    }

    //przygotowanie serii dla sygnalu EKG
    for(i = 0; i < dane_x.size(); i++)
    {
        series_line->append(dane_x[i], dane_y[i]);
    }


    series_scatter2->setMarkerShape(QScatterSeries::MarkerShapeCircle);
    //  series_scatter2->setColor(QColor::red());
    series_scatter2->setMarkerSize(10);
    //Tworzenie nowego wykresu
     Chart *chart = new Chart();
   // QChart *chart = new QChart();

    chart->legend()->hide();

    chart->setTitle("Umiejscowienie załamków R");
    //chart->createDefaultAxes();

    auto max = *max_element(std::begin(dane_y), std::end(dane_y));
    auto min = *min_element(std::begin(dane_y), std::end(dane_y));
    QValueAxis * axis_y = new QValueAxis();
    axis_y->setRange(min-2,max+2);
    axis_y->setTitleText("Voltage [mV]");


    QValueAxis * axis_x = new QValueAxis();
    axis_x->setRange(0,dane_y.size()+2);
    axis_x->setTitleText("Samples");


    //dodanie serii danych
    chart->addSeries(series_scatter2);
    chart->addSeries(series_line);

    chart->setAxisX(axis_x,series_line);
    chart->setAxisY(axis_y,series_line);

    chart->setAxisX(axis_x,series_scatter2);
    chart->setAxisY(axis_y,series_scatter2);
    chart->setAnimationOptions(QChart::AllAnimations);

    //chart->grabGesture(Qt::PanGesture);
    //chart->grabGesture(Qt::PinchGesture);

    return chart;
   // ui->chart_R->setChart(chart);
   // ui->chart_R->setRenderHints(QPainter::Antialiasing);
}


Chart *setChart_HRV_2()
{
/************************************HISTOGRAM********************************************/

    unsigned int i;

    //set dla osi X
    QBarSet *set0 = new QBarSet("Liczba załamków RR w danym czasie");
    //seria danych dla hist., oś y
    QBarSeries *series = new QBarSeries();


    //przedziały
    std::vector<double> przedzialy(10);
    przedzialy = {0,1,2,3,4,5,6,7,8,9};

    std::vector<std::string> string_przedzialy;


    QList<QString> list_przedzialy;

    for(i = 0; i < przedzialy.size(); i++)
    {
        list_przedzialy.append(QString::number(przedzialy[i]));
    }

    //tu będą wartości dla danych przedziałów - dane y
    std::vector<int> int_vector_y(10);
    int_vector_y = {1,2,3,4,5,6,7,8,9,1};

    //int to double
    std::vector<qreal> nowy_wektor(int_vector_y.begin(), int_vector_y.end());

    //przeksztalcenie na QVector
    QVector<double> nowy_wektor_q = QVector<double>::fromStdVector(nowy_wektor);
    //   nowy_wektor_q.fromStdVector(nowy_wektor);

    //QVector double to list double
    QList<qreal> nowy_wektor_list = nowy_wektor_q.toList();

    //ustawienie serii danych dla y
    set0->append(nowy_wektor_list);
    series->append(set0);

    Chart *hist = new Chart();
    hist->addSeries(series);
    hist->setTitle("Histogram odcinków RR");
    hist->setAnimationOptions(QChart::AllAnimations);



    QBarCategoryAxis *axis = new QBarCategoryAxis();
    axis->append(list_przedzialy);
    hist->createDefaultAxes();
    hist->legend()->setVisible(true);
    hist->legend()->setAlignment(Qt::AlignBottom);

   return hist;


/************************************POINCARE********************************************/



//Error: requested more datas

}

Chart *setChart_ECG_Baseline()
{

    //  QValueAxis *x_axis = new QValueAxis();

    //    x_axis->setTickCount(10);

     unsigned int i = 0;
     // tu będzie wektor danymi x - sygnał EKG
     std::vector<int> dane_x= {1,2,3,4,5,6};
     //a tu bedzie wektor z wartościami na ygrekach - sygnał EKG
     std::vector<int> dane_y = {2,15,1,4,22,6};

     //seria danych bazowych - sygnał EKG
     QLineSeries *series_line = new QLineSeries();

     //przygotowanie serii dla sygnalu EKG
     for(i = 0; i < dane_x.size(); i++)
     {
         series_line->append(dane_x[i], dane_y[i]);
     }


     //Tworzenie nowego wykresu
     Chart *chart = new Chart();

     //dodanie serii danych
     chart->addSeries(series_line);


     chart->legend()->hide();

     chart->setTitle("ECG Baseline");
     chart->createDefaultAxes();
     chart->zoomOut();
     chart->setAnimationOptions(QChart::AllAnimations);


   return chart;
}


